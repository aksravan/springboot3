$("#submitBtn").on('click', function () {
    const token = $("meta[name=_csrf]").attr('content');  // CSRF token

    var formData = new FormData();
    var file = document.getElementById('photo'); // Get the file
    console.log(file);
    formData.append('photo', file.files[0]);
    formData.append('_csrf', token);

    $.ajax({
        url: "/uploadFile", // The URL to send the request to
        type: "POST",
        data: formData,
        xhrFields: {
            withCredentials: true  // Ensures cookies are sent with the request
        },
        beforeSend: function (xhr) {
            // Optionally set custom headers (e.g., session ID) if needed
            var sessionId = getCookie("JSESSIONID");
            if (sessionId) {
                xhr.setRequestHeader("JSESSIONID", sessionId);
                xhr.setRequestHeader("X-CSRF-TOKEN", token);
            }
        },
        enctype: "",
        processData: false,  // Do not process the data (since we're sending FormData)
        contentType: false,  // Let jQuery set the correct content-type
        success: function (response) {
            console.log("Success:", response);
        },
        error: function (error) {
            console.log("Error:", error);
        }
    });
});

// Utility function to get cookies
function getCookie(name) {
    let cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i].trim();
        if (cookie.startsWith(name + '=')) {
            return cookie.substring(name.length + 1);
        }
    }
    return null;
}

function getBase64(file) {
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function () {
        console.log(reader.result);
        return reader.result;
    };
    reader.onerror = function (error) {
        console.log('Error: ', error);
    };
}
