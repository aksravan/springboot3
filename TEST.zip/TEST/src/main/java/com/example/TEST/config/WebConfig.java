package com.example.TEST.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.annotation.web.configurers.SessionManagementConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter.ReferrerPolicy;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
@EnableWebSecurity
public class WebConfig {

        @Autowired
        JdbcTemplate jdbcTemplate;

        @Bean
        public AuthSuccessHandler authSuccessHandler() {
                return new AuthSuccessHandler();
        }

        @Bean
        public AuthFailureHandler authFailureHandler() {
                return new AuthFailureHandler();
        }

        @Autowired
        private CustomAuthProvider authProvider;

        // @Bean
        // public AuthenticationManager authenticationManagerBean(HttpSecurity http)
        // throws Exception {
        // AuthenticationManagerBuilder authenticationManagerBuilder = http
        // .getSharedObject(AuthenticationManagerBuilder.class);
        // authenticationManagerBuilder.jdbcAuthentication()
        // .rolePrefix("ROLE_")
        // .dataSource(dataSource)
        // .usersByUsernameQuery("select username,password,enabled from users where
        // username = ?")
        // .passwordEncoder(passwordEncoder());
        // System.out.println("auth manager");
        // return authenticationManagerBuilder.build();
        // }

        @Bean
        public AuthenticationManager authManager(HttpSecurity http) throws Exception {
                AuthenticationManagerBuilder authenticationManagerBuilder = http
                                .getSharedObject(AuthenticationManagerBuilder.class);
                authenticationManagerBuilder.authenticationProvider(authProvider);
                return authenticationManagerBuilder.build();
        }

        @Bean
        public PasswordEncoder passwordEncoder() {
                DelegatingPasswordEncoder delPasswordEncoder = (DelegatingPasswordEncoder) PasswordEncoderFactories
                                .createDelegatingPasswordEncoder();
                BCryptPasswordEncoder bcryptPasswordEncoder = new BCryptPasswordEncoder();
                delPasswordEncoder.setDefaultPasswordEncoderForMatches(bcryptPasswordEncoder);
                return delPasswordEncoder;
        }

        @Bean
        public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

                http.addFilterBefore(new SessionCookieFilter(), UsernamePasswordAuthenticationFilter.class);
                http.authorizeHttpRequests(requests -> requests
                                .requestMatchers("/login", "/register", "/", "/js/**")
                                .permitAll()
                                .anyRequest().authenticated())
                                .formLogin(login -> login.loginPage("/login").permitAll()
                                                .successHandler(this.authSuccessHandler())
                                                .failureHandler(this.authFailureHandler())
                                                .failureUrl("/login?error=Not Found"))
                                .logout(logout -> logout.clearAuthentication(true).invalidateHttpSession(true)
                                                .deleteCookies("JSESSIONID")
                                                .logoutSuccessUrl("/"))
                                .exceptionHandling(handling -> handling.accessDeniedPage("/login?error=Access Denied"))
                                .headers(headers -> headers.frameOptions(options -> options.sameOrigin().disable())
                                                .contentSecurityPolicy(
                                                                policy -> policy.policyDirectives("form-action 'self'"))
                                                .referrerPolicy(refer -> refer.policy(ReferrerPolicy.SAME_ORIGIN)))
                                .sessionManagement(management -> management
                                                // .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
                                                // .sessionFixation(SessionManagementConfigurer.SessionFixationConfigurer::newSession)
                                                .maximumSessions(1).maxSessionsPreventsLogin(true)
                                                .expiredUrl("/login?invalid-session=true"))
                                .securityContext(
                                                context -> context.securityContextRepository(
                                                                new HttpSessionSecurityContextRepository()))
                                .cors(cor -> cor.configurationSource(corsConfigurationSource()));
                return http.build();
        }

        @Bean
        public CorsConfigurationSource corsConfigurationSource() {
                CorsConfiguration configuration = new CorsConfiguration();
                configuration.setAllowedOrigins(Arrays.asList("http://localhost:8181")); // Change to your frontend URL
                configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE"));
                configuration.setAllowedHeaders(Arrays.asList("Content-Type", "Authorization"));
                configuration.setAllowCredentials(true); // Allow credentials (cookies)

                UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
                source.registerCorsConfiguration("/**", configuration);
                return source;
        }

        // @Bean
        // public WebSecurityCustomizer ignoringCustomizer() {
        //         return (web) -> web.ignoring().requestMatchers("/uploadFile");
        // }

}