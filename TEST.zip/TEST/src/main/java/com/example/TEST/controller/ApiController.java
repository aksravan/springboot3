package com.example.TEST.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Base64;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class ApiController {

    @Value("${mediaPath}")
    String mediaPath;

    @PostMapping("/uploadFile")
    public String uploadFile(MultipartFile photo) throws Exception {

        // saving images
        String proof = "";
        String registrationID = "ASI";

        String path = mediaPath + File.separator + registrationID;

        // id proof
        if (photo != null && !photo.isEmpty()) {
            String name = photo.getOriginalFilename();
            String extension = FilenameUtils.getExtension(name);

            if (name != "") {
                byte[] bytes = photo.getBytes();
                File dir = new File(path + File.separator);

                if (!dir.exists())
                    dir.mkdirs();

                proof = dir.getAbsolutePath() + File.separator
                        + registrationID + "_id"
                        + "." + extension;

                File serverFile = new File(proof);

                // byte[] data = Base64.getDecoder().decode(photo);
                // try (OutputStream stream = new FileOutputStream("c:/decode/abc.bmp")) {
                //     stream.write(data);
                // }

                BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
                stream.write(bytes);
                stream.close();
            }
        }

        return "success";
    }

}
